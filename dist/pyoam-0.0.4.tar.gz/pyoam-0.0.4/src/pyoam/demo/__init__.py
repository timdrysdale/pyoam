"""Demo of different antenna factor calculations"""
